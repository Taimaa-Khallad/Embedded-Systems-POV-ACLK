void ATD_init(void); // Function for ATD initialization
void CCPPWM_init(void); // Function for CCP/PWM initialization
unsigned int ATD_read(void); // Function for reading analog input
void motor1(unsigned char);// Function for reading analog input


unsigned char myspeed;// Variable to store motor speed
void main() {
  unsigned int k; // Variable to store analog input value


  ATD_init(); // CALL the ATD module
  CCPPWM_init(); // CALL the CCP/PWM module
  while(1){

     k = ATD_read();  //0-1023  // Read analog input and store it in k


      myspeed= (((k>>2)*250)/255);// 0-250    // Calculate motor speed based on analog input (0-1023) and scale it to a range of 0-250

      motor1(myspeed);  // Control the motor speed using the calculated value

      }
 }
void ATD_init(void){
ADCON0=0x41;//ON, Channel 0, Fosc/16== 500KHz, Dont Go
ADCON1=0xCE;// RA0 Analog, others are Digital, Right Allignment,
TRISA=0x01; // Configure RA0 as input
}
unsigned int ATD_read(void){
         ADCON0=ADCON0 | 0x04;//GO
         while(ADCON0&0x04);//wait until DONE
         return (ADRESH<<8)|ADRESL; // Return the result of the conversion

}
void CCPPWM_init(void){ //Configure CCP1 and CCP2 at 2ms period with 50% duty cycle
  T2CON = 0x07;//enable Timer2 at Fosc/4 with 1:16 prescaler (8 uS percount 2000uS to count 250 counts)
  CCP1CON = 0x0C;//enable PWM for CCP1
  PR2 = 250;// 250 counts =8uS *250 =2ms period
  TRISC = 0x00; // Configure port C as output
  CCPR1L= 0; // Initialize PWM duty cycle to 0
}
void motor1(unsigned char speed){ //speed 0-250
       CCPR1L=speed;  // Set the PWM duty cycle for motor�control

}