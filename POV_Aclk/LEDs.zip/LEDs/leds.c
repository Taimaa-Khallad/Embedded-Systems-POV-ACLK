unsigned char counter = 0; // variable to count the number of obstacles.

void Blue(char); // A void function takes 1 if the blue LEDs are on and we want to turn them off, and 0 if they are off and we want to turn them on.
void Green(char);// A void function takes 1 if the Green LEDs are on and we want to turn them off, and 0 if they are off and we want to turn them on.
void myDelay(void); // A Dley function of 0.025 sec -> 50*1000*0.5us

void main() {
    TRISB = 0x00; // RB0-7 are outputs
    TRISD = 0x00; // RD0-7 are outputs
    TRISC = 0x01; // RC0 is an input for the sensor

    PORTB = 0x01; // Green leds are initially off and the red one is always on
    PORTD = 0x00; // Blue leds are initially off

    TMR0 = 0x00; // TMR0 is set to zero before start
    OPTION_REG = 0x07; // 256 Pre scale

    PORTC = 0x01; // sensor is off

    Blue(0); // Call the Blue function and all LEDs are initially off, it will turn them on.
    myDelay(); // a delay of 0.025 sec
    Green(0); // Call the function and the green LEDs are initially off, it will turn them on.

    while (1) {

        if (!(PORTC | 0x00)) { // if the sensor is on (an obstacle has been detected)
        counter++; //increment the counter

            if (counter==10) {// every ten counts the Blue leds will turn off
                Blue(1);  // to turn the Blue leds off
                counter=0; // restart the counter

            } else {
                Blue(0);// LEDS will be on
            }

           if (counter == 5) {// every five counts the green leds will turn off
                Green(1);  // to turn the Green leds off


            } else {
                Green(0);  // LEDS will be on

            }

          Delay_ms(500);     // a half sec delay
        }
    }
}

void myDelay(void) {
    unsigned int j;
    unsigned char i;
    for (i = 0; i < 50; i++) {
        for (j = 0; j < 1000; j++) {
            i = i;
            j = j;
        }
    }
}

void Blue(char S) {
    if (S) { // S=1 -> Blue LEDs are On
        PORTD = PORTD & 0x00; // turn them off
    } else { // S=0 -> Blue LEDs are Off
        PORTD = PORTD | 0xFF; // turn them on
    }
}

void Green(char S) {
    if (S) // S=1 -> Green LEDs are On
        PORTB = PORTB & 0x01; // turn them off
    else // S=0 -> Green LEDs are off
        PORTB = PORTB | 0xFF; // turn them on
}